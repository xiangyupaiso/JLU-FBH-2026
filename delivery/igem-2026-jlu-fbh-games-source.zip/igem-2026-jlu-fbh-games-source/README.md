# iGEM 2026 JLU-FBH — Games source code

Source code for the two interactive games published on the iGEM wiki.

| Game | Path | Stack | Images |
| :--- | :--- | :--- | :--- |
| 乳腺守护者 / Breast Guardian | `breast-guardian/` | React 19, TypeScript, Vite 7, Tailwind 3 | 201 assets → official iGEM CDN |
| circRNA 爆炸猫 / Bomb Cat | `bomb-cat/` | React 19, TypeScript, Vite 5, Tailwind 3 | none (native CSS / SVG / emoji) + 4 wiki fonts |

Each directory is a self-contained npm project with its own lockfile, config and
`README.md`.

## Contents of this archive

```
.
├── README.md                      this file
├── IGEM_ASSET_REGISTRY.md         the team's asset registry (the mapping source of truth)
├── breast-guardian/
│   ├── README.md                  full docs: structure, commands, wiki integration, limitations
│   ├── ASSET_MAPPING.md           generated: 201 local paths → official URLs
│   ├── src/
│   │   ├── data/assetUrls.ts      GENERATED: the URL map the game resolves every image through
│   │   ├── data/assets.ts         character / boss / scene resolvers
│   │   ├── data/generatedAssets.ts eager preload list (176 URLs)
│   │   ├── data/stories.ts        all story scripts
│   │   ├── sections/              one component per game phase
│   │   ├── components/            WikiBridge, AssetPreloader, UI primitives
│   │   ├── hooks/, lib/, types/
│   │   ├── App.tsx, App.css, index.css, main.tsx
│   ├── scripts/
│   │   ├── regen_asset_urls.py    regenerate the map from the registry
│   │   └── check-runtime-assets.mjs  assert every real call site resolves
│   └── index.html, package.json, package-lock.json, vite.config.ts, tsconfig*.json,
│       tailwind.config.js, postcss.config.js, eslint.config.js, components.json
└── bomb-cat/
    ├── README.md                  full docs
    ├── src/
    │   ├── CircRnaGame.tsx        main component
    │   ├── components/WikiBridge.tsx
    │   ├── circure-skin.css       wiki skin: iGEM fonts, paper texture, radii
    │   ├── components/, constants/, engine/, hooks/, types/
    │   └── App.tsx, main.tsx, index.css, vite-env.d.ts
    └── index.html, package.json, package-lock.json, vite.config.ts, tsconfig.json,
        tailwind.config.js, postcss.config.js
```

## Requirements

- **Node.js ≥ 20** (developed on 24.x), npm ≥ 10
- **Python ≥ 3.9** — only for Breast Guardian's `assets:regen` / `check:assets`
- Network access to `static.igem.wiki` (all artwork and fonts load remotely)
- For Bomb Cat **Online Play**: access to the PeerJS signalling server

## Install and build

```bash
# Breast Guardian
cd breast-guardian
npm ci
npm run dev                                   # http://localhost:5173
npm run build                                 # -> dist/
npm run assets:regen && npm run check:assets  # regenerate/verify the image map
npm run check:runtime                         # assert every call site resolves

# Bomb Cat
cd ../bomb-cat
npm ci
npm run dev
npm run build                                 # -> dist/
```

Both projects default to `base: './'`, so `dist/` can be served from any path.

To build Bomb Cat for its wiki subdirectory (`/game-assets/bomb-cat/`):

```bash
GAME_BASE_PATH=/game-assets/bomb-cat/ npm run build        # Linux / macOS
$env:GAME_BASE_PATH = '/game-assets/bomb-cat/'; npm run build   # PowerShell
```

## Where the images come from

Breast Guardian used to ship a ~270 MB `public/assets/` tree. It now contains **no
image binaries**. Every portrait, scene and UI plate resolves through
`breast-guardian/src/data/assetUrls.ts` to an official `static.igem.wiki` URL.

That map is **generated** from `IGEM_ASSET_REGISTRY.md`, the team's single source of
truth for uploaded media. No URL is ever inferred from a filename, and the remote
extension is not assumed to match the local one — iGEM serves AVIF regardless of what
was uploaded. See `breast-guardian/ASSET_MAPPING.md` for the full table and
`breast-guardian/README.md` for the "Known limitations" section (including the assets
that are uploaded but unreferenced, and one duplicate).

Bomb Cat has **no image assets at all** — cards, board and icons are native Tailwind,
inline SVG from `lucide-react`, and emoji text. Its only remote assets are four iGEM
web fonts declared in `bomb-cat/src/circure-skin.css`. See that README for the
evidence and reasoning.

## Not included

- `node_modules/`, `dist/`, caches, `.tsbuildinfo` — run `npm ci`
- Image binaries — load from the official iGEM server
- The source projects' unused `public/assets/raw/` (~175 unsorted images)
- The compiled bundles served by the live wiki (those live in the wiki repo under
  `public/game-assets/`)
- Any credentials or machine-local configuration

## Verified at packaging time

- `npm ci` + `npm run build` succeed for both projects; TypeScript is clean
- Breast Guardian `check:runtime`: 182 distinct official URLs across every scene,
  every 【立绘】 pair in the story data, every shipped boss state and the full preload
  list — 0 unresolved, 0 non-iGEM, 0 not-in-registry
- Bundle audit: 0 image `src` values outside the official iGEM CDN
- 204 referenced official URLs (200 images + 4 fonts) HTTP `HEAD`-checked: all 200 OK