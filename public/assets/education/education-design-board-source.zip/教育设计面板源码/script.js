'use strict';
// Canonical source: 6.2 Education (4), pp. 7–10; format interpretations
// draw on the practice sections. These rules are illustrative design guidance,
// not empirical coefficients or an implementation of the PDF's formal model.
const ART = {
  "医生": "assets/医生.png",
  "大学": "assets/大学.png",
  "工程师": "assets/工程师.png",
  "画家": "assets/画家.png",
  "移液枪": "assets/移液枪.png",
  "程序员": "assets/程序员.png",
  "细胞朋友": "assets/细胞朋友.png",
  "翻卡牌": "assets/翻卡牌.png",
  "讲课": "assets/讲课.png",
  "辩论": "assets/辩论.png"
};
const FORMATS = [
{id:'explanation',name:'Guided Explanation',asset:'讲课',role:'Conceptual foundations',supports:['cognitive'],description:'Builds conceptual foundations and makes mechanisms explicit.',detail:'Use a brief explanation with a checked diagram and a learner question.',requirements:'Minimal materials; any space. Keep language and analogies appropriate.',cost:1},
{id:'discussion',name:'Discussion',asset:'辩论',role:'Dialogue & judgement',supports:['cognitive','affective'],description:'Adds dialogue about evidence, experience and values.',detail:'Invite learners to explain their reasoning and listen to a different position.',requirements:'Minimal materials; any space. Allow private or written responses.',cost:1},
{id:'wetlab',name:'Wet Lab',asset:'移液枪',role:'Material experience',supports:['experiential'],description:'Adds real operation, error and material uncertainty.',detail:'Connect a supervised operation to its purpose, observed result and uncertainty.',requirements:'Extended time, a team, laboratory equipment and laboratory space. Qualified supervision is essential.',cost:3},
{id:'virtual',name:'Virtual Laboratory',asset:'程序员',role:'Procedural exploration',supports:['experiential','cognitive'],description:'Adds procedural exploration when physical access or continuity is limited.',detail:'Let learners operate, revisit steps and explain how one result connects to the next.',requirements:'Moderate or extended time and digital equipment. A virtual laboratory does not replace physical practice.',cost:2},
{id:'game',name:'Educational Game',asset:'翻卡牌',role:'Choice & consequences',supports:['experiential','cognitive'],description:'Turns scientific relationships into choices, consequences and reflection.',detail:'Use a short process game, then discuss where its rules differ from real science.',requirements:'Minimal materials; any space. Online play needs digital equipment.',cost:1},
{id:'plasmid',name:'Plasmid Design',asset:'工程师',role:'Engineering judgement',supports:['cognitive','experiential'],description:'Extends concepts into engineering choices under constraints.',detail:'Ask learners to justify component choices for a stated goal, rather than choose the strongest combination.',requirements:'Moderate or extended time. Paper component cards can support design without a wet lab.',cost:2},
{id:'narrative',name:'Narrative / Storytelling',asset:'细胞朋友',role:'Personal connection',supports:['affective'],description:'Connects science with personal experience and opens space for reflection.',detail:'Pair a short story with a scientific explanation; keep the metaphor and mechanism distinct.',requirements:'Minimal materials; any space. Offer choice about personal sharing.',cost:1},
{id:'creative',name:'Creative Activity',asset:'画家',role:'Expression & creation',supports:['affective','experiential'],description:'Lets learners express experience through making and shared reflection.',detail:'Invite a drawing, message or simple model, then ask what it means to its creator.',requirements:'Moderate or extended time; paper materials or digital creative tools.',cost:2},
{id:'publichealth',name:'Public-health Interaction',asset:'医生',role:'Situated health dialogue',supports:['affective','cognitive'],description:'Connects reliable health knowledge to questions in a public setting.',detail:'Create a short, optional conversation around a checked health resource.',requirements:'Public space, moderate or extended time and a team. Specialist questions need qualified support.',cost:2},
{id:'digital',name:'Digital Resource',asset:'大学',role:'Return & revisit',supports:['cognitive'],description:'Provides a reusable explanation learners can revisit at their own pace.',detail:'Use an accessible diagram or reading guide with a clear route to further explanation.',requirements:'Digital equipment. This board assumes an existing, reviewed resource; production time must be planned separately.',cost:1}
];
const keys=['cognitive','affective','experiential'];
const labels={cognitive:'Cognitive',affective:'Affective',experiential:'Experiential'};
let built=false, opened=null, lastPortfolio=[];
const $=id=>document.getElementById(id);
function context(){return {needs:Object.fromEntries(keys.map(k=>[k,document.querySelector('input[name="'+k+'"]:checked').value])),time:$('time').value,staff:$('staff').value,equipment:$('equipment').value,space:$('space').value};}
function unavailable(f,c){
 if(c.space==='online'&&c.equipment==='minimal')return 'Online participation needs digital access.';
 if(f.id==='wetlab'){
  if(c.equipment!=='lab'||c.space!=='lab')return 'Needs laboratory equipment and space.';
  if(c.time!=='extended')return 'Needs extended time, including setup.';
  if(c.staff==='limited')return 'Needs a team and qualified supervision.';
 }
 if(['virtual','digital'].includes(f.id)&&c.equipment==='minimal')return 'Needs digital equipment.';
 if(['virtual','plasmid','creative','publichealth'].includes(f.id)&&c.time==='short')return 'Needs more time in this guide.';
 if(f.id==='publichealth'&&c.space!=='public')return 'Designed for public space.';
 if(f.id==='publichealth'&&c.staff==='limited')return 'Needs a team for public interaction.';
 return '';
}
// A bounded sequence, not a bag of individually feasible formats. "Cost" is
// a rough planning unit only. Never display it as time, quality or evidence.
function allowance(c){if(c.time==='short')return 2;if(c.time==='moderate')return c.staff==='limited'?3:4;return c.staff==='limited'?4:c.staff==='small'?6:7;}
function recommend(c){
 if(c.space==='online'&&c.equipment==='minimal')return [];
 const set=[],budget=allowance(c);let used=0;
 const add=id=>{const f=FORMATS.find(f=>f.id===id);if(set.some(x=>x.id===id)||unavailable(f,c)||used+f.cost>budget||set.length===4)return false;set.push(f);used+=f.cost;return true;};
 const priority=keys.filter(k=>c.needs[k]==='primary').concat(keys.filter(k=>c.needs[k]==='important'));
 if(!priority.length)priority.push('cognitive');
 for(const k of priority){
  if(k==='cognitive')add(c.space==='online'?'digital':'explanation');
  if(k==='affective')add(c.space==='public'&&c.staff!=='limited'&&c.time!=='short'?'publichealth':'narrative');
  if(k==='experiential'){
   if(!add('wetlab')){
    if(c.needs.cognitive==='primary'&&c.time==='extended'&&c.equipment==='minimal')add('plasmid');
    else if(c.needs.affective==='primary'&&c.needs.cognitive!=='primary')add('creative');
    else add('virtual');
    if(!set.some(f=>f.supports.includes('experiential')))add('game');
   }
  }
 }
 if(!set.length)add('explanation');
 // Add a distinct learning job, only when it fits the whole sequence.
 if(c.needs.cognitive==='primary'&&c.needs.experiential!=='supporting'&&c.time==='extended')add('plasmid');
 if(set.length===1){
  if(set[0].id==='narrative')add('discussion');
  else if(set[0].supports.includes('experiential'))add('explanation');
  else add('discussion');
 }
 if(c.needs.affective==='important'&&!set.some(f=>f.supports.includes('affective')))add('discussion');
 return set;
}
function renderShelf(){const c=context();$('tokens').innerHTML=FORMATS.map(f=>{const reason=unavailable(f,c),selected=built&&lastPortfolio.some(p=>p.id===f.id);return '<button type="button" class="token '+(reason?'unavailable ':'')+(selected?'selected':'')+'" data-format="'+f.id+'" aria-expanded="'+(opened===f.id)+'" aria-controls="format-detail" aria-label="'+f.name+'. '+(selected?'In suggested portfolio. ':reason?'Needs other resources. ':'Available to consider. ')+'View details"><img src="'+ART[f.asset]+'" alt="" width="100" height="65"><span class="name">'+f.name+'</span><span class="state">'+(reason?'Needs other resources':selected?'In your portfolio':'Available to consider')+'</span></button>';}).join('');if(opened)showDetail(opened);}
function showDetail(id){const f=FORMATS.find(f=>f.id===id),reason=unavailable(f,context());$('format-detail').hidden=false;$('format-detail').innerHTML='<strong>'+f.name+' · '+f.role+'</strong><p>'+f.detail+'</p><p><b>Plan for:</b> '+f.requirements+'</p>'+(reason?'<p><b>Current limit:</b> '+reason+'</p>':'');}
function renderResult(announce=true){
 const c=context();lastPortfolio=recommend(c);$('empty').hidden=true;$('result').hidden=false;
 $('portfolio-list').innerHTML=lastPortfolio.map(f=>'<li class="portfolio-card"><img src="'+ART[f.asset]+'" alt="" width="75" height="81"><div><div class="role">'+f.role+'</div><h3>'+f.name+'</h3><p>'+f.description+'</p></div></li>').join('');
 const covered=Object.fromEntries(keys.map(k=>[k,lastPortfolio.some(f=>f.supports.includes(k))]));
 $('coverage').innerHTML=keys.map(k=>'<div><dt>'+labels[k]+' coverage</dt><dd>'+(!lastPortfolio.length?'Not assessed':covered[k]?'Strong':c.needs[k]==='supporting'?'Supporting':'Needs attention')+'</dd></div>').join('');
 if(!lastPortfolio.length){
  $('fit').innerHTML='<strong>Resource fit — Needs adjustment</strong>Online participation needs a suitable device. Add digital equipment or choose an in-person space.';
  $('tradeoff').innerHTML='<b>Resolve this condition first.</b> No portfolio is suggested while the selected space and equipment conflict.';
 }else{
  const times={short:'a short explanation or reflection paired with one brief activity',moderate:'a bounded session with time for participation and reflection',extended:'a sequenced learning route across an extended session or multiple sessions'};
  const spaces={online:'online',classroom:'in a classroom',lab:'in laboratory space',public:'in a public space'};
  const equipment=c.equipment==='minimal'?'Uses paper or minimal materials.':'Uses available digital equipment'+(lastPortfolio.some(f=>f.id==='wetlab')?' and laboratory materials.':'; no wet-lab access is needed.');
  const staff=c.staff==='limited'?'Keep facilitation simple for 1–2 people.':c.staff==='small'?'Share facilitation and preparation across a small team.':'Assign clear roles across the larger team.';
  const wetNote=lastPortfolio.some(f=>f.id==='wetlab')?' Confirm qualified supervision, protocols and safe waste handling before proceeding.':'';
  $('fit').innerHTML='<strong>Resource fit — Compatible in principle</strong>Plan '+times[c.time]+' '+spaces[c.space]+'. '+equipment+' '+staff+wetNote;
  const gaps=keys.filter(k=>c.needs[k]!=='supporting'&&!covered[k]);
  let note=gaps.length?'<b>Keep the limit visible.</b> '+gaps.map(k=>labels[k]).join(' and ')+' needs more dedicated attention than this combination provides. Rebalance the emphasis or expand time and support.':'<b>Each format has a different job.</b> '+(lastPortfolio.length===2?'Keep this pair focused; extra formats would add preparation without a clear new learning task.':'Sequence these roles rather than run disconnected activities. Add another format only when it fills a distinct need.');
  if(lastPortfolio.some(f=>f.id==='virtual'))note+=' Virtual practice develops procedural understanding; it does not reproduce physical handling or real experimental uncertainty.';
  $('tradeoff').innerHTML=note;
 }
 $('build').hidden=true;$('assumption').style.marginTop='0';
 if(announce)$('live-note').textContent=lastPortfolio.length?'Portfolio updated · '+lastPortfolio.length+' complementary formats':'Resources need adjustment before a portfolio can be built.';
 $('portfolio-list').classList.remove('enter');void $('portfolio-list').offsetWidth;$('portfolio-list').classList.add('enter');renderShelf();
}
document.querySelectorAll('form').forEach(f=>{f.addEventListener('submit',e=>e.preventDefault());f.addEventListener('change',()=>{if(built)renderResult();else renderShelf();});});
$('tokens').addEventListener('click',e=>{const b=e.target.closest('[data-format]');if(!b)return;const id=b.dataset.format;opened=opened===id?null:id;if(opened)showDetail(opened);else $('format-detail').hidden=true;document.querySelectorAll('[data-format]').forEach(t=>t.setAttribute('aria-expanded',String(t.dataset.format===opened)));});
$('build').addEventListener('click',()=>{built=true;renderResult();$('portfolio-title').setAttribute('tabindex','-1');$('portfolio-title').focus({preventScroll:true});});
$('reset').addEventListener('click',()=>{$('needs-form').reset();$('resource-form').reset();built=false;opened=null;lastPortfolio=[];$('empty').hidden=false;$('result').hidden=true;$('build').hidden=false;$('format-detail').hidden=true;renderShelf();document.querySelector('input[name=cognitive]:checked').focus({preventScroll:true});$('design').scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth',block:'start'});});
renderShelf();
