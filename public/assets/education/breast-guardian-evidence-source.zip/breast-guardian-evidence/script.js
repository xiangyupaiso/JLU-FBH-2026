'use strict';
// Aggregate values only. No participant-level observations are generated.
const evidenceData=Object.freeze({sample:24,questionnaires:26,recovery:92.3,playtime:{mean:42.5,sd:9.8,range:[28,65]},core:[57.6,83.3],tnbc:[37.5,79.2],familiarity:{synbio:[3.04,3.63],rna:[2.71,3.46]},hospital:[22,15],themes:[13,11,10,7]});
const tabs=[...document.querySelectorAll('[data-view]')],seen=new Set();
function selectView(id,focus=false){tabs.forEach((tab,i)=>{const active=tab.dataset.view===id;tab.setAttribute('aria-selected',String(active));tab.tabIndex=active?0:-1;document.getElementById('panel-'+tab.dataset.view).hidden=!active;if(active){seen.add(id);if(focus)tab.focus();}tab.classList.toggle('seen',seen.has(tab.dataset.view));document.querySelectorAll('.stamps i')[i].classList.toggle('seen',seen.has(tab.dataset.view));});document.getElementById('progress').textContent=seen.size===4?'Evidence Complete · 4 of 4 explored':`${seen.size} of 4 evidence files explored`;if(seen.size===4){document.getElementById('journey-link').textContent='Continue beyond the numbers ↓';}document.getElementById('status').textContent=tabs.find(t=>t.dataset.view===id).querySelector('b').textContent+' opened. '+seen.size+' of 4 files explored.';}
tabs.forEach((tab,i)=>{tab.addEventListener('click',()=>selectView(tab.dataset.view));tab.addEventListener('keydown',e=>{let j;if(e.key==='ArrowRight'||e.key==='ArrowDown')j=(i+1)%tabs.length;if(e.key==='ArrowLeft'||e.key==='ArrowUp')j=(i+tabs.length-1)%tabs.length;if(e.key==='Home')j=0;if(e.key==='End')j=tabs.length-1;if(j!==undefined){e.preventDefault();selectView(tabs[j].dataset.view,true);}});});
const tokens=document.getElementById('tokens');
// 24 identical aggregate pictograms; placement carries no individual identity.
tokens.innerHTML=Array.from({length:24},()=>'<svg class="participant" viewBox="0 0 32 42" aria-hidden="true"><path d="M16 3c5 0 8 3 8 8s-3 8-8 8-8-3-8-8 3-8 8-8Z M5 38l1-10c1-5 5-7 10-7s9 2 10 7l1 10c-7 2-15 2-22 0Z"/></svg>').join('');
function setHospital(count){document.querySelectorAll('[data-hospital]').forEach(b=>b.setAttribute('aria-pressed',String(Number(b.dataset.hospital)===count)));document.querySelectorAll('.participant').forEach((t,i)=>t.classList.toggle('active',i<count));document.getElementById('hospital-count').textContent=count;const copy=count===22?'reported gaining new understanding':'reported significantly deepened understanding';document.getElementById('hospital-copy').textContent=copy;tokens.setAttribute('aria-label',`${count} of 24 participant tokens highlighted: ${copy}`);document.getElementById('status').textContent=`${count} of 24 ${copy}.`;}
document.querySelectorAll('[data-hospital]').forEach(b=>b.addEventListener('click',()=>setHospital(Number(b.dataset.hospital))));
const themes=['Family health responsibility appeared in 13 of 24 coded responses.','Symptom awareness / Boss memory appeared in 11 of 24 coded responses.','Lifestyle reflection appeared in 10 of 24 coded responses.','Synthetic biology / circRNA recognition appeared in 7 of 24 coded responses.'];
document.querySelectorAll('[data-theme]').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('[data-theme]').forEach(x=>x.setAttribute('aria-pressed',String(x===b)));document.getElementById('theme-copy').textContent=themes[Number(b.dataset.theme)];}));
// Exact nodes and branches from canonical N24 HTML. Educational descriptions
// summarize Education (4); they are conceptual, not additional outcome measures.
const pathway=[['Narrative','Situates health knowledge in familiar life experiences.'],['Healthy choice','Connects choices and their consequences with health knowledge.'],['Replay','Creates space to revisit decisions and reconsider their consequences.'],['Boss','Connects remembered choices with symptom challenges in the game.'],['Future Hospital','Introduces TNBC, synthetic biology and circRNA within the game world.'],['Reflection','Invites players to reconsider what their experience means.'],['Health intention','Connects reflection with possible health intentions; actual behaviour change was not established.'],['Family connection','Places personal health in the context of family and intergenerational relationships.']];
const islands=[...document.querySelectorAll('[data-step]')];
let selectedStep=0;
function selectIsland(index){selectedStep=index;islands.forEach((x,i)=>x.setAttribute('aria-pressed',String(i===index)));const [title,copy]=pathway[index];const p=document.getElementById('step-copy');p.replaceChildren();const strong=document.createElement('strong');strong.textContent=title;p.append(strong,document.createTextNode(' — '+copy));highlightRiver();}
islands.forEach((button,i)=>button.addEventListener('click',()=>selectIsland(i)));
function highlightRiver(){document.querySelectorAll('.river-segment').forEach(segment=>{const nodes=segment.dataset.nodes.split(',').map(Number);segment.classList.toggle('river-selected',nodes.includes(selectedStep));});}
// Equal-width illustrative waterways. Widths encode no people or measurements.
// Exact source topology: 0→1→2→{3,4}→5→{6,7}.
const riverEdges=[[0,1],[1,2],[2,3],[2,4],[3,5],[4,5],[5,6],[5,7]];
function drawRiver(){
 const landscape=document.getElementById('river-landscape'),bounds=landscape.getBoundingClientRect(),vertical=matchMedia('(max-width:600px)').matches;
 const svg=document.getElementById('river-water');svg.setAttribute('viewBox',`0 0 ${bounds.width} ${bounds.height}`);
 const points=islands.map(button=>{const box=button.querySelector('.island-art').getBoundingClientRect();return {x:box.left-bounds.left+box.width/2,y:box.top-bounds.top+box.height*.73};});
 const group=document.getElementById('river-paths');group.replaceChildren();
 const ns='http://www.w3.org/2000/svg';
 function segment(d,nodes){const g=document.createElementNS(ns,'g');g.classList.add('river-segment');g.dataset.nodes=nodes.join(',');for(const cls of ['river-bank','river-fill','river-ripple']){const p=document.createElementNS(ns,'path');p.setAttribute('d',d);p.setAttribute('class',cls);g.append(p);}group.append(g);}
 function curve(a,b){if(vertical){const dy=(b.y-a.y)*.6;return `M${a.x},${a.y} C${a.x},${a.y+dy} ${b.x},${b.y-dy} ${b.x},${b.y}`;}const dx=(b.x-a.x)*.52;return `M${a.x},${a.y} C${a.x+dx},${a.y} ${b.x-dx},${b.y} ${b.x},${b.y}`;}
 const first=points[0];segment(curve(vertical?{x:first.x-25,y:5}:{x:3,y:first.y-40},first),[0]);
 riverEdges.forEach(([a,b])=>segment(curve(points[a],points[b]),[a,b]));
 for(const n of [6,7]){const p=points[n];segment(curve(p,vertical?{x:p.x+(n===6?-20:20),y:bounds.height-7}:{x:bounds.width-5,y:p.y+(n===6?-15:15)}),[n]);}
 const p=points[2],rx=vertical?36:43,ry=vertical?25:26;segment(`M${p.x},${p.y} C${p.x-rx*1.8},${p.y-ry*1.6} ${p.x+rx*1.8},${p.y-ry*1.6} ${p.x+rx},${p.y} C${p.x+rx*.7},${p.y+ry} ${p.x-rx*.8},${p.y+ry} ${p.x},${p.y}`,[2]);
 highlightRiver();
}
let riverFrame;const scheduleRiver=()=>{cancelAnimationFrame(riverFrame);riverFrame=requestAnimationFrame(drawRiver);};
new ResizeObserver(scheduleRiver).observe(document.getElementById('river-landscape'));
window.addEventListener('load',scheduleRiver);document.fonts.ready.then(scheduleRiver);
setHospital(22);selectView('knowledge');scheduleRiver();
