# Breast Guardian — Evidence Room

Open `Breast Guardian Evidence Room.html` directly in a browser. It contains all CSS, JavaScript and illustrations and makes no external requests.

Editable source: `index.html`, `style.css`, `script.js`, `assets/`. Open `index.html` with these files beside it, or serve the folder with a static server. No build step or dependencies are required for use. Run `python package.py` to regenerate the portable HTML and source ZIP after editing.

For a Wiki embed, upload the standalone file and embed it in an iframe with a descriptive title and an appropriate responsive height. The file works independently without external fonts, libraries or APIs.

## Sources and decisions

Canonical evaluation: user-provided `Breast_Guardian_N24_Paired_Evaluation_Wiki.html`. Context: `6.2 Education (4).pdf`, pp. 30–33. Styling and illustrations reuse the existing Education Design Board assets.

The page contains aggregate data, not individual participant records. Knowledge accuracy and self-reported familiarity are presented separately. “Significantly deepened” is a reported category, not a significance test. No p-values are introduced from the PDF because the N24 HTML is the canonical numerical source for this tool.

The conceptual pathway retains the original HTML topology: Narrative → Healthy choice → Replay → {Boss, Future Hospital} → Reflection → {Health intention, Family connection}. Links do not encode participant counts. Conceptual descriptions summarize the current Wiki and are not additional measured outcomes.

Feedback themes overlap. No invented player quotations are used. A compact scientific-boundary note remains below the river: immediate post-game signals only, single session, no control group, no long-term follow-up. Exploration progress is a browsing aid only and is not saved or transmitted.

## Learning River refinement

The upper Evidence Room is preserved, except that its completion link now points to the learning river. Eight purpose-drawn transparent watercolor scenes replace the button flowchart. The river branches at Replay, converges at Reflection, then branches again. Clicking any island selects its connected water segments and shows one conceptual caption. River widths do not encode participant counts or measured effects.

Desktop uses a horizontal landscape; mobile uses an alternating vertical river with visible branch and merge. Water motion respects reduced-motion settings. All islands remain native keyboard-accessible buttons with text labels.

The large boundary notebook has been removed. At 1440px, the complete page is 1610px tall compared with the prior 1805px; the desktop river section is approximately 525px tall. Verification covers 1920, 1440, 768, 600, 390 and 320px widths, all eight islands, all original evidence controls, exact canonical numbers, offline images and zero external requests.

New art was made using the built-in imagegen tool. The eight original illustrations and exact final prompts are in `assets/river-*.png` and `assets/generation-notes.md`.

## Data checklist

24 / 26 valid matched pairs; 92.3% valid recovery. Playtime mean 42.5 min, SD 9.8 min, range 28–65 min.

Core knowledge 57.6% → 83.3%, +25.7 percentage points. TNBC 37.5% → 79.2%, +41.7 percentage points.

Self-reported familiarity, 1–5: synthetic biology 3.04 → 3.63; RNA / circRNA 2.71 → 3.46.

Future Hospital: 22 / 24 new understanding; 15 / 24 significantly deepened. Feedback counts: 13, 11, 10, 7 out of 24.
