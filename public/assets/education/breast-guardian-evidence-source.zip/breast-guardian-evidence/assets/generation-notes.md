# Learning River illustration assets

Generated with the built-in imagegen tool. Transparent PNG originals are preserved in assets/river-*.png.

## narrative

An open storybook resting on a mossy little riverbank, a tiny warm memory lantern, pink blossoms, a few stepping stones. Book is blank, no writing.

## choice

A tiny grassy island with two winding footpaths, a rustic heart-shaped wooden signpost, dusty pink wildflowers and rounded river stones.

## replay

An oval turquoise backwater pool with a small central grassy island, curling circular water current clearly visible, reeds, pale lilac stones, a little empty wooden boat.

## boss

A small rocky challenge arena island, lavender rocks forming a ring around three little abstract friendly coral and purple cell-like creatures, reddish flowers. Not scary.

## hospital

A tiny blue-white future hospital research building on a sage green river island, pale blue medical cross on facade, circular RNA motif on one window, small wooden landing dock, reeds and flowers.

## reflection

A beautiful still turquoise mirror lake, curved grassy shore, a little ochre lantern reflected in the lake, gentle concentric ripples, reeds and pale stones. Lake is the main subject.

## intention

A small sage green river delta island with an antique pocket compass beside a small coral heart-shaped stone and new plant shoots. Warm ochre compass case, no letters or numerals.

## family

Two tiny pastel cottages on two grassy riverbanks connected by an arched ochre wooden footbridge over a narrow turquoise stream, flowers and stepping stones.

## Shared final prompt

Use case: illustration-story. Asset type: one transparent-background illustrated island token for a hand-drawn scientific education game-world map. [Scene above] Style: delicate watercolor washes and colored-pencil contours on warm cream paper, muted sage, dusty pink, pale blue, turquoise and ochre. Soft organic irregular edges and fine hand-drawn brown outlines, restrained editorial storybook illustration, matching CirCure Education Wiki. Three-quarter overhead view, wide compact composition with the complete scene centered inside generous transparent margin. All scenery must be fully visible without cropping. True transparent outside the island. No labels, text, numbers, UI, arrows, rectangular cards, gradients, glowing effects, 3D renders, or drop shadow. Single cohesive scene only.

