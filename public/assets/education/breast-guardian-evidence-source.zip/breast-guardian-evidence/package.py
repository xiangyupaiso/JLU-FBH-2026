from pathlib import Path
import base64, zipfile

root=Path(__file__).parent
html=(root/'index.html').read_text(encoding='utf-8')
html=html.replace('<link rel="stylesheet" href="style.css">','<style>'+ (root/'style.css').read_text(encoding='utf-8')+'</style>')
html=html.replace('<script src="script.js"></script>','<script>'+ (root/'script.js').read_text(encoding='utf-8')+'</script>')
for path in (root/'assets').glob('*.png'):
    html=html.replace('assets/'+path.name,'data:image/png;base64,'+base64.b64encode(path.read_bytes()).decode())
output=root/'Breast Guardian Evidence Room.html'
output.write_text(html,encoding='utf-8')
with zipfile.ZipFile(root.parent/'Breast-Guardian-Evidence-Source.zip','w',zipfile.ZIP_DEFLATED) as z:
    for path in [root/'index.html',root/'style.css',root/'script.js',root/'README.md',root/'package.py',output,*list((root/'assets').glob('*.png')),*list((root/'assets').glob('*.md'))]:
        z.write(path,'breast-guardian-evidence/'+str(path.relative_to(root)))
print('Packaged standalone HTML and editable source ZIP.')
