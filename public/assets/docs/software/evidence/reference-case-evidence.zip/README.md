# Software Wiki evidence

These files distinguish existing-file verification from a compiler rerun,
RNA prediction and wet-lab validation. They contain no participant logs.

Run `python verify_reference_files.py` in this directory to check the archived
reference and generated sequences, coding invariants and validation ZIP hashes.
The script uses the standard library and does not contact external services.

The reference-case run is dated 2026-10-01. The Wiki file checks and public-source
inspection are dated 2026-10-17. Candidate index IDs are editorial keys based on
source coordinates, not original laboratory identifiers. Unmatched Wet Lab labels
are left empty rather than guessed. Sequence hashes use uppercase sequences
without headers or whitespace. DNA and RNA hashes are distinct.
Combined fragment DNA is extracted from the Combined reference; it is not a
recovered complete first-round plasmid sequence or a per-construct lab release.

The upstream TorusFold artifact remains an earlier-build model. The accompanying
Wiki viewer changes presentation only, retaining the original embedded PDB bytes.
The normalized reference-region comparison is not a recovered historical export
or independent experimental confirmation of a mature-RNA boundary.
