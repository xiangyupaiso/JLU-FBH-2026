"""Check the supplied reference-case files with Python's standard library.

This checks existing files. It does not run the compiler, a predictor, or an
experiment. Run beside reference_original.gb, reconstructed_construct.gbk,
reviewed_payload_ground_truth.csv and reconstructed_construct_validation.zip.
"""
from pathlib import Path
import csv
import hashlib
import itertools
import json
import re
import zipfile

HERE = Path(__file__).resolve().parent
BASES = "TCAG"
AA = "FFLLSSSSYY**CC*WLLLLPPPPHHQQRRRRIIIMTTTTNNKKSSRRVVVVAAAADDEEGGGG"
CODE = dict(zip(("".join(x) for x in itertools.product(BASES, repeat=3)), AA))


def sequence(path):
    origin = path.read_text(encoding="utf-8").split("ORIGIN", 1)[1].split("//", 1)[0]
    return "".join(re.findall("[ACGTacgt]+", origin)).upper()


def translate(dna):
    assert len(dna) % 3 == 0
    return "".join(CODE[dna[i:i + 3]] for i in range(0, len(dna), 3))


def main():
    reference = sequence(HERE / "reference_original.gb")
    generated = sequence(HERE / "reconstructed_construct.gbk")
    with (HERE / "reviewed_payload_ground_truth.csv").open(encoding="utf-8", newline="") as f:
        fragments = list(csv.DictReader(f))
    expected = "GSGGS".join(row["Peptide"] for row in fragments)
    a, b = reference[1605:1941], generated[1605:1941]
    differences = [(a[i:i + 3], b[i:i + 3]) for i in range(0, len(a), 3) if a[i:i + 3] != b[i:i + 3]]
    checks = {
        "reference_length_5267": len(reference) == 5267,
        "generated_length_5267": len(generated) == 5267,
        "eight_input_segments": len(fragments) == 8,
        "payload_length_336_nt": len(a) == len(b) == 336,
        "payload_length_112_aa": len(expected) == 112,
        "reference_payload_order_and_linkers": translate(a) == expected,
        "generated_payload_order_and_linkers": translate(b) == expected,
        "outside_region_unchanged": reference[:1605] == generated[:1605] and reference[1941:] == generated[1941:],
        "outside_region_length_4931": len(reference) - len(a) == 4931,
        "changed_codons_54": len(differences) == 54,
        "changed_bases_67": sum(x != y for x, y in zip(a, b)) == 67,
        "all_changed_codons_synonymous": all(CODE[x] == CODE[y] for x, y in differences),
        "full_fusion_translation_preserved": translate(reference[1503:2586]) == translate(generated[1503:2586]),
        "no_internal_stop_in_fusion": "*" not in translate(generated[1503:2586])[:-1],
    }
    checksum_rows = []
    with zipfile.ZipFile(HERE / "reconstructed_construct_validation.zip") as archive:
        manifest = json.loads(archive.read("bundle_manifest.json"))
        entries = manifest.get("files", manifest.get("inventory", []))
        # The exact bundle schema is also available for direct inspection.
        checks["bundle_zip_integrity"] = archive.testzip() is None
        if isinstance(entries, list):
            for entry in entries:
                name = entry.get("path", entry.get("file", entry.get("name")))
                expected_hash = entry.get("sha256")
                if name and expected_hash:
                    checksum_rows.append(hashlib.sha256(archive.read(name)).hexdigest().lower() == expected_hash.lower())
        with (HERE / "bundle_checksum_checks.csv").open(encoding="utf-8", newline="") as f:
            recorded = list(csv.DictReader(f))
        for row in recorded:
            actual = hashlib.sha256(archive.read(row["File"])).hexdigest()
            checksum_rows.append(actual.lower() == row["ExpectedSHA256"].lower())
        checks["eleven_recorded_files_match_hashes"] = len(recorded) == 11 and all(checksum_rows)
    if (HERE / "torusfold-model-sequence.txt").exists():
        normalize = lambda s: "".join(s.split()).upper().replace("T", "U")
        checks["documented_reference_region_matches_saved_model_input"] = normalize(reference[722:2735]) == normalize((HERE / "torusfold-model-sequence.txt").read_text(encoding="ascii"))
    result = {"scope": "Existing-file consistency only; no compiler rerun, prediction or wet experiment", "checks": checks, "passed": sum(checks.values()), "total": len(checks), "all_pass": all(checks.values())}
    print(json.dumps(result, indent=2))
    return 0 if result["all_pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
